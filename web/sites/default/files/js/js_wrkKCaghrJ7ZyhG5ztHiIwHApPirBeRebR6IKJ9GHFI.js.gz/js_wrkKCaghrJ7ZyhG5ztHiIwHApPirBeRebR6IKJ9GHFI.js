/**
 * @file
 * Global utilities.
 *
 */
(function ($, Drupal) {

  'use strict';

  Drupal.behaviors.subtema_nro1 = {
    attach: function (context, settings) {

    }
  };

})(jQuery, Drupal);
;
